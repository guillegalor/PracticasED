var searchData=
[
  ['columnas',['columnas',['../classTablero.html#ac70289ec91b44d05da648770cc46801d',1,'Tablero']]]
];
