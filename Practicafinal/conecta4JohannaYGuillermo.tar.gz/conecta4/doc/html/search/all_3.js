var searchData=
[
  ['derecha',['derecha',['../classArbolGeneral_1_1inorden__iterador.html#a374dc7ff5ed5e568ca496f103cf73a5d',1,'ArbolGeneral::inorden_iterador::derecha()'],['../classArbolGeneral_1_1postorden__iterador.html#ae2b24cd3445cac918c67574c0879b189',1,'ArbolGeneral::postorden_iterador::derecha()']]],
  ['destruir',['destruir',['../classArbolGeneral.html#aba5f46f715343b9ee4952c30da065f8f',1,'ArbolGeneral']]],
  ['drcha',['drcha',['../structArbolGeneral_1_1nodo.html#a8d0a58447171461212942f9308ef4f36',1,'ArbolGeneral::nodo']]]
];
