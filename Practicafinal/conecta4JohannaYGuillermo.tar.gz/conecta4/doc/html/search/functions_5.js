var searchData=
[
  ['getarbol',['GetArbol',['../classJugadorAuto.html#a74531aa932becde453fe8667f6455413',1,'JugadorAuto']]],
  ['getbase',['GetBase',['../classMando.html#abcc813b0881e56ed976eea2ce6b7fd12',1,'Mando']]],
  ['getcolumnas',['GetColumnas',['../classTablero.html#a3cc99292123bdc0c33fcede9ce79e1bf',1,'Tablero']]],
  ['getfilas',['GetFilas',['../classTablero.html#ae8807f83521eb77c8e7b762f9122f51a',1,'Tablero']]],
  ['getjugador',['GetJugador',['../classMando.html#aaf8c918ecbce5c8173fcf40e04c8b0b7',1,'Mando']]],
  ['getmando',['GetMando',['../classMando.html#a7e02a04343208f949a88e720ba63a281',1,'Mando']]],
  ['gettablero',['GetTablero',['../classTablero.html#ad9ddec339ebecf5e081433b0509c8c47',1,'Tablero']]],
  ['getturno',['GetTurno',['../classTablero.html#abf7a05a4b7463c1bd605d0b0a04add4f',1,'Tablero']]]
];
