var searchData=
[
  ['jugadorauto',['JugadorAuto',['../classJugadorAuto.html#a28f4b4c52165488379729d71237a41a9',1,'JugadorAuto::JugadorAuto()'],['../classJugadorAuto.html#a0c2bc2690a8e6ba93b05a83b9310a03e',1,'JugadorAuto::JugadorAuto(const Tablero &amp;t)']]]
];
