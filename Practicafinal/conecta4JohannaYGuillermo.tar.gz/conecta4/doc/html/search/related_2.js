var searchData=
[
  ['preorden_5fiterador',['preorden_iterador',['../classArbolGeneral_1_1reverse__preorden__iterador.html#a4aa0da8bfbc320a8daff98451ee65b6c',1,'ArbolGeneral::reverse_preorden_iterador']]]
];
