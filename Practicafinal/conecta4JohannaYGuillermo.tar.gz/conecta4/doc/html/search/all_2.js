var searchData=
[
  ['cambiarturno',['cambiarTurno',['../classTablero.html#a6a07659599bca3442cce101d7bf42b9a',1,'Tablero']]],
  ['clear',['clear',['../classArbolGeneral.html#a3ae21db42586b23ccc082aeb321db56f',1,'ArbolGeneral']]],
  ['colocarficha',['colocarFicha',['../classTablero.html#a24bbcc0cf0a9e464f37a261cd9c6ff45',1,'Tablero']]],
  ['columnas',['columnas',['../classTablero.html#ac70289ec91b44d05da648770cc46801d',1,'Tablero']]],
  ['contar',['contar',['../classArbolGeneral.html#ac53afcc4c99179132bf593781d7c927f',1,'ArbolGeneral']]],
  ['contar_5fhijos',['contar_Hijos',['../classArbolGeneral.html#a6a56e71e7f38894d58b9649a653d0948',1,'ArbolGeneral']]],
  ['copiar',['copiar',['../classArbolGeneral.html#a79f31cbba599abea7ab8b2f4ac7bef91',1,'ArbolGeneral']]]
];
