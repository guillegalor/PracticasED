var searchData=
[
  ['reverse_5fpreorden_5fiterador',['reverse_preorden_iterador',['../classArbolGeneral_1_1preorden__iterador.html#ad7df6535fb84021c7c3804850af9fdcd',1,'ArbolGeneral::preorden_iterador']]]
];
