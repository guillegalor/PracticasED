var searchData=
[
  ['quiengana',['quienGana',['../classTablero.html#a5de543f8186142731ab3ac77944a11b1',1,'Tablero']]]
];
