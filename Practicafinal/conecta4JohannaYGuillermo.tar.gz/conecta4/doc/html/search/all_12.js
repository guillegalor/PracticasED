var searchData=
[
  ['settablero',['SetTablero',['../classTablero.html#a811481680b64300b21fb4d1e9619e795',1,'Tablero']]],
  ['size',['size',['../classArbolGeneral.html#a69a2c10bedbf77dbc23baea0a731a02d',1,'ArbolGeneral']]],
  ['soniguales',['soniguales',['../classArbolGeneral.html#a47e7ab8321b8ae2e11fc279caabf72de',1,'ArbolGeneral']]]
];
