var searchData=
[
  ['tablero',['tablero',['../classTablero.html#a5df607d108c0c0a14aa4f393b7f43030',1,'Tablero']]],
  ['turno',['turno',['../classTablero.html#ae460b4a3245da075dd381365abf158bc',1,'Tablero']]]
];
