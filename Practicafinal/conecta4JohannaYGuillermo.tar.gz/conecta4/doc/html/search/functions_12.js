var searchData=
[
  ['_7earbolgeneral',['~ArbolGeneral',['../classArbolGeneral.html#a085c45825063913fb958b704f59033f3',1,'ArbolGeneral']]],
  ['_7etablero',['~Tablero',['../classTablero.html#a7d4a64967ce0bbe2cce49ec846834c84',1,'Tablero']]]
];
