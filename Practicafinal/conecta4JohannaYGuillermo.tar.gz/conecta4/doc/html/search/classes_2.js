var searchData=
[
  ['jugadorauto',['JugadorAuto',['../classJugadorAuto.html',1,'']]]
];
