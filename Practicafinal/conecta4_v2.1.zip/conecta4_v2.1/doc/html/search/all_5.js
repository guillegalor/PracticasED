var searchData=
[
  ['filas',['filas',['../classTablero.html#a6b1f04a8502106c33bf5469f791320e6',1,'Tablero']]]
];
