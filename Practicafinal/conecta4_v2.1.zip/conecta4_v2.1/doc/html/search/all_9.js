var searchData=
[
  ['jugador',['jugador',['../classMando.html#ab4791c4f5bb306c1bbcf95047e010163',1,'Mando']]]
];
