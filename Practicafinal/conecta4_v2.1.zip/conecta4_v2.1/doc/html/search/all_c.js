var searchData=
[
  ['mando',['Mando',['../classMando.html',1,'Mando'],['../classMando.html#a156e71bce6ea523dccbce03021bee4dd',1,'Mando::mando()'],['../classMando.html#a2e2ed3e8f3502f7d99cee3e1278cafb9',1,'Mando::Mando(Tablero t)']]],
  ['mando_2eh',['mando.h',['../mando_8h.html',1,'']]]
];
