var searchData=
[
  ['etiqueta',['etiqueta',['../structArbolGeneral_1_1nodo.html#ab7223965c5a62aa93895f3decd7a109a',1,'ArbolGeneral::nodo']]]
];
