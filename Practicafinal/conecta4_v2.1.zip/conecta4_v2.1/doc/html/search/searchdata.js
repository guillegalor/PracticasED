var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrst~",
  1: "aimnprt",
  2: "agmt",
  3: "abcdeghilmnopqrst~",
  4: "bcdefijklmnpt",
  5: "n",
  6: "aopr",
  7: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "&apos;typedefs&apos;",
  6: "Amigas",
  7: "Páginas"
};

