var searchData=
[
  ['n_5ffichas_5fganar',['N_FICHAS_GANAR',['../classTablero.html#aa38ed353bef45bd6c5a2e3aa4a897720',1,'Tablero']]]
];
