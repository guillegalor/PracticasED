var searchData=
[
  ['p',['p',['../classArbolGeneral_1_1preorden__iterador.html#afac01ba5fdc1e10c2a808d92f1dbddaf',1,'ArbolGeneral::preorden_iterador::p()'],['../classArbolGeneral_1_1reverse__preorden__iterador.html#a002862fdee453a84b037e5dd26c071a2',1,'ArbolGeneral::reverse_preorden_iterador::p()'],['../classArbolGeneral_1_1inorden__iterador.html#a77d9424a41cf406909fe131c11ccc856',1,'ArbolGeneral::inorden_iterador::p()'],['../classArbolGeneral_1_1postorden__iterador.html#ae269432023776674c7633eadeb8c30e0',1,'ArbolGeneral::postorden_iterador::p()']]],
  ['padre',['padre',['../structArbolGeneral_1_1nodo.html#ab4d70a0179e8450b2842bbf1a6481402',1,'ArbolGeneral::nodo']]],
  ['posicion',['posicion',['../classMando.html#a7971a6eaa8b936977be7460ffa28530f',1,'Mando']]]
];
